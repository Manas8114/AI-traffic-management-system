document.addEventListener('DOMContentLoaded', function() {
    const videoContainer = document.getElementById('video-container');
    const systemStatus = document.getElementById('system-status');
    const activeCameras = document.getElementById('active-cameras');
    const activeIncidents = document.getElementById('active-incidents');
    const incidentsList = document.getElementById('incidents-list');
    const lightStatus = document.getElementById('light-status');
    
    // Chart initialization
    const densityCtx = document.getElementById('density-chart').getContext('2d');
    const densityChart = new Chart(densityCtx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Traffic Density',
                data: [],
                borderColor: '#3498db',
                backgroundColor: 'rgba(52, 152, 219, 0.1)',
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
    
    // Fetch camera info
    function loadCameras() {
        fetch('/api/cameras')
            .then(response => response.json())
            .then(data => {
                activeCameras.textContent = `${data.active.length} active`;
                
                // Clear existing video feeds
                videoContainer.innerHTML = '';
                
                // Add video feeds
                data.active.forEach(camera => {
                    const videoFeed = document.createElement('div');
                    videoFeed.className = 'video-feed';
                    
                    const img = document.createElement('img');
                    img.src = `/api/stream/${camera}`;
                    img.alt = `Camera ${camera}`;
                    
                    const cameraName = document.createElement('div');
                    cameraName.className = 'camera-name';
                    cameraName.textContent = `Camera ${camera}`;
                    
                    videoFeed.appendChild(img);
                    videoFeed.appendChild(cameraName);
                    videoContainer.appendChild(videoFeed);
                });
            })
            .catch(error => console.error('Error loading cameras:', error));
    }
    
    // Fetch system status
    function loadStatus() {
        fetch('/api/status')
            .then(response => response.json())
            .then(data => {
                const uptimeHours = Math.floor(data.uptime / 3600);
                const uptimeMinutes = Math.floor((data.uptime % 3600) / 60);
                systemStatus.innerHTML = `
                    <div>Uptime: ${uptimeHours}h ${uptimeMinutes}m</div>
                    <div>Processed frames: ${data.processed_frames}</div>
                    <div>CPU: ${data.system_load}%</div>
                    <div>Memory: ${data.memory_usage}%</div>
                `;
            })
            .catch(error => console.error('Error loading status:', error));
    }
    
    // Fetch traffic data
    function loadTrafficData() {
        fetch('/api/traffic')
            .then(response => response.json())
            .then(data => {
                // Update traffic lights display
                lightStatus.innerHTML = '';
                Object.entries(data.lights).forEach(([lane, state]) => {
                    const lightElement = document.createElement('div');
                    lightElement.innerHTML = `
                        <span>Lane ${lane}: </span>
                        <span class="light ${state}"></span>
                    `;
                    lightStatus.appendChild(lightElement);
                });
                
                // Update chart with latest data point
                if (data.history && data.history.length > 0) {
                    const latestData = data.history.slice(-10); // Get last 10 points
                    
                    densityChart.data.labels = latestData.map(item => {
                        const date = new Date(item.timestamp * 1000);
                        return date.toLocaleTimeString();
                    });
                    
                    // Sum up densities across all lanes
                    densityChart.data.datasets[0].data = latestData.map(item => {
                        return Object.values(item.densities).reduce((sum, val) => sum + val, 0);
                    });
                    
                    densityChart.update();
                }
            })
            .catch(error => console.error('Error loading traffic data:', error));
    }
    
    // Fetch incidents
    function loadIncidents() {
        fetch('/api/incidents')
            .then(response => response.json())
            .then(data => {
                activeIncidents.textContent = data.active.length;
                
                // Update incidents list
                incidentsList.innerHTML = '';
                
                // Display active incidents first
                data.active.forEach(incident => {
                    const incidentElement = document.createElement('div');
                    incidentElement.className = 'incident-item';
                    
                    const startTime = new Date(incident.start_time).toLocaleTimeString();
                    incidentElement.innerHTML = `
                        <strong>${incident.type.replace('_', ' ')}</strong>
                        <div>Started: ${startTime}</div>
                        <div>Status: Active</div>
                    `;
                    
                    incidentsList.appendChild(incidentElement);
                });
                
                // Then show recent resolved incidents
                data.history.filter(inc => inc.status === 'resolved').slice(0, 5).forEach(incident => {
                    const incidentElement = document.createElement('div');
                    incidentElement.className = 'incident-item resolved';
                    
                    const startTime = new Date(incident.start_time).toLocaleTimeString();
                    const endTime = incident.end_time ? new Date(incident.end_time).toLocaleTimeString() : 'N/A';
                    
                    incidentElement.innerHTML = `
                        <strong>${incident.type.replace('_', ' ')}</strong>
                        <div>Started: ${startTime}</div>
                        <div>Resolved: ${endTime}</div>
                    `;
                    
                    incidentsList.appendChild(incidentElement);
                });
            })
            .catch(error => console.error('Error loading incidents:', error));
    }
    
    // Load initial data
    loadCameras();
    loadStatus();
    loadTrafficData();
    loadIncidents();
    
    // Set up periodic refreshes
    setInterval(loadStatus, 5000);
    setInterval(loadTrafficData, 2000);
    setInterval(loadIncidents, 5000);
    setInterval(loadCameras, 30000);
});