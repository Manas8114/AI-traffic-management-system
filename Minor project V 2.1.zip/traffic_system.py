import numpy as np
import cv2
from ultralytics import YOLO
from pymongo import MongoClient
from datetime import datetime, timedelta
import threading
from queue import Queue, Empty
import logging
import os
import time
import json
from concurrent.futures import ThreadPoolExecutor
from dotenv import load_dotenv
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import LSTM, Dense
from sklearn.preprocessing import MinMaxScaler
import pytesseract
from collections import defaultdict
from typing import Dict, List, Tuple, Optional, Any, Union
from flask import Flask, render_template, Response, jsonify, request
from cryptography.fernet import Fernet
import requests
from twilio.rest import Client
import uuid
import yaml
import signal
import sys
import argparse

# Load configuration
def load_config(config_path="config.yml"):
    """Load configuration from YML file with environment variable substitution"""
    try:
        with open(config_path, 'r') as file:
            config = yaml.safe_load(file)

        # Substitute environment variables
        for section, values in config.items():
            if isinstance(values, dict):
                for key, value in values.items():
                    if isinstance(value, str) and value.startswith("${") and value.endswith("}"):
                        env_var = value[2:-1]
                        config[section][key] = os.getenv(env_var, "")

        return config
    except Exception as e:
        print(f"Error loading config: {e}")
        return {
            "logging": {"level": "INFO", "file": "traffic_system.log"},
            "traffic": {"lane_divisions": 3, "min_green_time": 10, "yellow_duration": 3, "red_duration": 2},
            "cameras": {"urls": []},
            "detection": {"model_path": "yolov8n.pt", "speed_limit": 50},
            "prediction": {"update_interval": 60},
            "incidents": {"stopped_threshold": 10, "congestion_threshold": 0.7},
            "system": {"worker_threads": 2}
        }

# Load environment variables
load_dotenv()
CONFIG = load_config()

# Configure logging
logging.basicConfig(
    level=getattr(logging, CONFIG.get("logging", {}).get("level", "INFO")),
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler(CONFIG.get("logging", {}).get("file", "traffic_system.log")),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Constants from config or defaults
LANE_DIVISIONS = CONFIG.get("traffic", {}).get("lane_divisions", 3)
MIN_GREEN_TIME = CONFIG.get("traffic", {}).get("min_green_time", 10)
YELLOW_DURATION = CONFIG.get("traffic", {}).get("yellow_duration", 3)
RED_DURATION = CONFIG.get("traffic", {}).get("red_duration", 2)
CAMERA_URLS = CONFIG.get("cameras", {}).get("urls", [])
MODEL_PATH = CONFIG.get("detection", {}).get("model_path", "yolov8n.pt")

# Security Configuration
try:
    ENCRYPTION_KEY = os.getenv("ENCRYPTION_KEY") or Fernet.generate_key()
    cipher_suite = Fernet(ENCRYPTION_KEY)
except Exception as e:
    logger.error(f"Encryption configuration failed: {e}")
    cipher_suite = None

# Twilio Alerts Configuration
TWILIO_ACCOUNT_SID = os.getenv("TWILIO_ACCOUNT_SID")
TWILIO_AUTH_TOKEN = os.getenv("TWILIO_AUTH_TOKEN")
TWILIO_PHONE_NUMBER = os.getenv("TWILIO_PHONE_NUMBER")
ALERT_PHONE_NUMBER = os.getenv("ALERT_PHONE_NUMBER")
twilio_client = None

if all([TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_PHONE_NUMBER]):
    try:
        twilio_client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
        logger.info("Twilio client initialized successfully")
    except Exception as e:
        logger.error(f"Twilio client initialization failed: {e}")

# MongoDB Configuration
MONGO_URI = os.getenv("MONGODB_URI")
db_client = None
traffic_db = None

if MONGO_URI:
    try:
        db_client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=5000)
        db_client.server_info()  # Test connection
        traffic_db = db_client.traffic
        logger.info("MongoDB connection established")
    except Exception as e:
        logger.error(f"MongoDB connection failed: {e}")

class VehicleTracker:
    """Tracks vehicle movement, speed and stores history"""

    def __init__(self, max_history: int = 100, cleanup_interval: int = 60):
        self.vehicle_history = defaultdict(list)
        self.max_history = max_history
        self.last_cleanup = time.time()
        self.cleanup_interval = cleanup_interval

    def update(self, track_id: int, x: float, y: float) -> None:
        """Update position history for a tracked vehicle"""
        self.vehicle_history[track_id].append((x, y, time.time()))
        if len(self.vehicle_history[track_id]) > self.max_history:
            self.vehicle_history[track_id] = self.vehicle_history[track_id][-self.max_history:]

        # Periodically clean up old vehicles
        if time.time() - self.last_cleanup > self.cleanup_interval:
            self._cleanup_history()

    def get_speed(self, track_id: int, time_window: int = 3) -> float:
        """Calculate vehicle speed in pixels/second over the given time window"""
        history = self.vehicle_history.get(track_id, [])
        if len(history) < 2:
            return 0.0

        # Find points within time window
        current_time = history[-1][2]
        window_start = current_time - time_window
        window_points = [p for p in history if p[2] >= window_start]

        if len(window_points) < 2:
            return 0.0

        # Calculate displacement
        start_x, start_y = window_points[0][0], window_points[0][1]
        end_x, end_y = window_points[-1][0], window_points[-1][1]
        dx = end_x - start_x
        dy = end_y - start_y
        distance = np.sqrt(dx**2 + dy**2)

        # Calculate time difference
        dt = window_points[-1][2] - window_points[0][2]

        if dt <= 0:
            return 0.0

        return distance / dt

    def is_stopped(self, track_id: int, threshold: float = 5.0, samples: int = 10) -> bool:
        """Check if vehicle is stopped (moving less than threshold)"""
        history = self.vehicle_history.get(track_id, [])
        if len(history) < samples:
            return False

        recent = history[-samples:]
        avg_x = sum(p[0] for p in recent) / len(recent)
        avg_y = sum(p[1] for p in recent) / len(recent)

        max_deviation = max(
            np.sqrt((p[0] - avg_x)**2 + (p[1] - avg_y)**2) for p in recent
        )

        return max_deviation < threshold

    def _cleanup_history(self) -> None:
        """Remove vehicles that haven't been updated recently"""
        current_time = time.time()
        inactive_threshold = 10  # seconds

        inactive_ids = [
            tid for tid, history in self.vehicle_history.items()
            if current_time - history[-1][2] > inactive_threshold
        ]

        for tid in inactive_ids:
            del self.vehicle_history[tid]

        self.last_cleanup = current_time
        logger.debug(f"Cleaned up {len(inactive_ids)} inactive vehicles")

class EnhancedVehicleDetector:
    """Advanced vehicle detection and tracking with violation checking"""

    def __init__(self, model_path: str, confidence: float = 0.25):
        if not os.path.exists(model_path):
            logger.warning(f"Model not found at {model_path}, using YOLO default")
            self.model = YOLO("yolov8n.pt")  # Use default model as fallback
        else:
            self.model = YOLO(model_path)

        self.tracker = VehicleTracker()
        self.violation_history = []
        self.confidence = confidence
        self.lane_boundaries = []  # Will be set based on frame dimensions
        self.speed_limit = CONFIG.get("detection", {}).get("speed_limit", 50)
        self.classes_of_interest = [
            "car", "truck", "bus", "motorcycle", "bicycle",
            "ambulance", "police", "fire truck", "person"
        ]

    def set_lane_boundaries(self, frame_width: int) -> None:
        """Setup lane boundaries based on frame width"""
        self.lane_boundaries = [
            (i * frame_width / LANE_DIVISIONS, (i+1) * frame_width / LANE_DIVISIONS)
            for i in range(LANE_DIVISIONS)
        ]

    def detect_and_track(self, frame: np.ndarray) -> Tuple[dict, dict, bool, np.ndarray, list]:
        try:
            if not self.lane_boundaries and frame is not None:
                self.set_lane_boundaries(frame.shape[1])

            results = self.model.track(frame, persist=True, conf=self.confidence)
            annotated_frame = frame.copy()
            lane_densities = defaultdict(int)
            vehicle_counts = defaultdict(int)
            emergency_present = False
            violations = []

            for result in results:
                if not result.boxes:
                    continue

                boxes = result.boxes.xyxy.cpu().numpy()
                class_ids = result.boxes.cls.cpu().numpy().astype(int)
                confidences = result.boxes.conf.cpu().numpy()
                track_ids = result.boxes.id.cpu().numpy().astype(int) if result.boxes.id is not None else []

                for idx, (box, class_id, conf) in enumerate(zip(boxes, class_ids, confidences)):
                    if idx >= len(track_ids):
                        continue

                    track_id = track_ids[idx]
                    cls = self.model.names[class_id]

                    if cls not in self.classes_of_interest:
                        continue

                    vehicle_counts[cls] += 1
                    x_center = (box[0] + box[2]) / 2
                    y_center = (box[1] + box[3]) / 2

                    # Update tracker
                    self.tracker.update(track_id, x_center, y_center)

                    # Determine lane
                    lane_idx = 0
                    for i, (start, end) in enumerate(self.lane_boundaries):
                        if start <= x_center < end:
                            lane_idx = i
                            break

                    lane_densities[lane_idx] += 1

                    # Check for emergency vehicles
                    if cls in ["ambulance", "police", "fire truck"]:
                        emergency_present = True

                    # Check for speed violations
                    speed = self.tracker.get_speed(track_id)
                    if speed > self.speed_limit:
                        violations.append({
                            "type": "speed",
                            "track_id": track_id,
                            "vehicle_type": cls,
                            "speed": speed,
                            "position": (x_center, y_center),
                            "timestamp": datetime.now()
                        })

                    # Visualize the detection
                    color = (0, 165, 255) if speed > self.speed_limit else (0, 255, 0)

                    # Draw bounding box
                    cv2.rectangle(annotated_frame,
                                  (int(box[0]), int(box[1])),
                                  (int(box[2]), int(box[3])),
                                  color, 2)

                    # Add text with details
                    label = f"{cls} #{track_id} {conf:.2f}"
                    if speed > 0:
                        label += f" {speed:.1f}px/s"

                    cv2.putText(annotated_frame, label,
                                (int(box[0]), int(box[1]) - 10),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)

            return vehicle_counts, lane_densities, emergency_present, annotated_frame, violations
        except Exception as e:
            logger.error(f"Detection error: {e}", exc_info=True)
            return defaultdict(int), defaultdict(int), False, frame, []

class TrafficPredictor:
    """LSTM-based traffic prediction with adaptive learning"""

    def __init__(self, model_path: Optional[str] = None):
        self.sequence_length = 30
        self.feature_columns = ["time_of_day", "day_of_week", "density"]
        self.min_samples_for_prediction = self.sequence_length * 2

        self.scaler = MinMaxScaler(feature_range=(0, 1))
        self.model = self._load_or_build_model(model_path)
        self.history = []
        self.update_interval = CONFIG.get("prediction", {}).get("update_interval", 60)  # seconds
        self.last_training = 0

    def _load_or_build_model(self, model_path: Optional[str]) -> Sequential:
        """Load existing model or build new one"""
        if model_path and os.path.exists(model_path):
            try:
                logger.info(f"Loading traffic prediction model from {model_path}")
                return load_model(model_path)
            except Exception as e:
                logger.error(f"Failed to load model: {e}")

        logger.info("Building new LSTM prediction model")
        model = Sequential([
            LSTM(64, return_sequences=True, input_shape=(self.sequence_length, len(self.feature_columns))),
            LSTM(64),
            Dense(1)
        ])
        model.compile(optimizer='adam', loss='mse')
        return model

    def _create_features(self, timestamp: datetime, density: float) -> List[float]:
        """Create feature vector with time context"""
        # Normalize time of day (hour + minute/60) to be between 0-1
        time_of_day = timestamp.hour + timestamp.minute/60
        time_of_day_normalized = time_of_day / 24.0

        # Day of week as normalized value (0-1)
        day_of_week_normalized = timestamp.weekday() / 6.0

        return [time_of_day_normalized, day_of_week_normalized, density]

    def save_model(self, path: str) -> None:
        """Save model to disk"""
        try:
            self.model.save(path)
            logger.info(f"Model saved to {path}")
        except Exception as e:
            logger.error(f"Failed to save model: {e}")

    def update_and_predict(self, densities: dict) -> dict:
        """Update history and predict future density"""
        try:
            current_time = datetime.now()
            current_density = sum(densities.values())

            # Add new data point with timestamp
            self.history.append({
                "timestamp": current_time,
                "density": current_density,
                "features": self._create_features(current_time, current_density)
            })

            # Keep reasonable history size
            if len(self.history) > 24*60*60:  # One day of history at per-second sampling
                self.history = self.history[-24*60*60:]

            # Retrain periodically if we have enough data
            if (time.time() - self.last_training > self.update_interval and
                len(self.history) >= self.min_samples_for_prediction):
                self._retrain_model()

            # Generate prediction
            if len(self.history) >= self.min_samples_for_prediction:
                prediction = self._predict_next()
                return {
                    "current": current_density,
                    "predicted": prediction,
                    "percent_change": ((prediction - current_density) / current_density * 100)
                                      if current_density > 0 else 0,
                    "timestamp": current_time.isoformat()
                }
            return {
                "current": current_density,
                "timestamp": current_time.isoformat()
            }
        except Exception as e:
            logger.error(f"Prediction error: {e}", exc_info=True)
            return {"current": sum(densities.values()), "timestamp": datetime.now().isoformat()}

    def _predict_next(self) -> float:
        """Predict next density value"""
        recent_features = [entry["features"] for entry in self.history[-self.sequence_length:]]
        X = np.array([recent_features])

        # Scale features
        X_scaled = np.zeros_like(X)
        for i in range(len(self.feature_columns)):
            # Time-based features are already normalized
            if i < 2:
                X_scaled[:, :, i] = X[:, :, i]
            else:
                # Scale density
                feature_values = X[:, :, i].reshape(-1, 1)
                X_scaled[:, :, i] = self.scaler.fit_transform(feature_values).reshape(X.shape[0], X.shape[1])

        # Make prediction
        prediction_scaled = self.model.predict(X_scaled)[0][0]

        # Reverse scaling for density only
        dummy_array = np.zeros((self.sequence_length, 1))
        dummy_array[0] = prediction_scaled
        prediction = self.scaler.inverse_transform(dummy_array)[0][0]

        return float(prediction)

    def _retrain_model(self) -> None:
        """Retrain model with accumulated data"""
        try:
            if len(self.history) < self.min_samples_for_prediction:
                return

            # Extract features from history
            all_features = [entry["features"] for entry in self.history]

            # Prepare training data
            X, y = [], []
            for i in range(len(all_features) - self.sequence_length):
                X.append(all_features[i:i+self.sequence_length])
                # We're only predicting the density component
                y.append(all_features[i+self.sequence_length][2])

            X = np.array(X)
            y = np.array(y).reshape(-1, 1)

            # Scale features
            X_scaled = np.zeros_like(X)
            for i in range(len(self.feature_columns)):
                if i < 2:  # Time-based features already normalized
                    X_scaled[:, :, i] = X[:, :, i]
                else:
                    feature_values = X[:, :, i].reshape(-1, 1)
                    X_scaled[:, :, i] = self.scaler.fit_transform(feature_values).reshape(X.shape[0], X.shape[1])

            # Scale target
            y_scaled = self.scaler.transform(y)

            # Train model
            self.model.fit(
                X_scaled, y_scaled,
                epochs=5,
                batch_size=32,
                verbose=0,
                validation_split=0.2
            )

            self.last_training = time.time()
            logger.info(f"Retrained model with {len(X)} samples")

        except Exception as e:
            logger.error(f"Model retraining failed: {e}", exc_info=True)

class IncidentDetector:
    """Real-time incident detection system"""

    def __init__(self):
        self.stopped_vehicles = {}
        self.accident_threshold = CONFIG.get("incidents", {}).get("stopped_threshold", 10)  # Seconds
        self.congestion_threshold = CONFIG.get("incidents", {}).get("congestion_threshold", 0.7)  # Density ratio
        self.incidents = []
        self.active_incidents = set()  # Track incident IDs that are currently active

    def detect(self, vehicle_tracker: VehicleTracker, lane_densities: dict, frame_dimensions: Tuple[int, int]) -> List[dict]:
        """Detect various traffic incidents"""
        current_incidents = []
        current_time = time.time()
        frame_area = frame_dimensions[0] * frame_dimensions[1]

        # Check for stopped vehicles
        for vid, history in vehicle_tracker.vehicle_history.items():
            if len(history) < 10:
                continue

            if vehicle_tracker.is_stopped(vid):
                # Add to stopped vehicles tracking
                if vid not in self.stopped_vehicles:
                    self.stopped_vehicles[vid] = current_time
                elif current_time - self.stopped_vehicles[vid] > self.accident_threshold:
                    # Create stopped vehicle incident
                    incident_id = f"stopped_{vid}_{int(current_time)}"
                    if incident_id not in self.active_incidents:
                        self.active_incidents.add(incident_id)
                        incident = {
                            "id": incident_id,
                            "type": "stopped_vehicle",
                            "track_id": vid,
                            "position": history[-1][:2],
                            "start_time": datetime.fromtimestamp(self.stopped_vehicles[vid]),
                            "duration": current_time - self.stopped_vehicles[vid],
                            "status": "active"
                        }
                        current_incidents.append(incident)
                        self.incidents.append(incident)
            else:
                # Vehicle is moving again, close any active incidents
                for incident in self.incidents:
                    if (incident["status"] == "active" and
                        incident["type"] == "stopped_vehicle" and
                        incident["track_id"] == vid):
                        incident["status"] = "resolved"
                        incident["end_time"] = datetime.fromtimestamp(current_time)
                        self.active_incidents.remove(incident["id"])

                # Remove from stopped tracking
                self.stopped_vehicles.pop(vid, None)

        # Check for congestion
        total_density = sum(lane_densities.values())
        lane_count = len(lane_densities) if lane_densities else LANE_DIVISIONS
        avg_vehicles_per_lane = total_density / lane_count if lane_count > 0 else 0

        # Simple congestion heuristic: density exceeds X vehicles per lane
        congestion_threshold = 5  # Example: more than 5 vehicles per lane on average

        if avg_vehicles_per_lane > congestion_threshold:
            congestion_id = f"congestion_{int(current_time)}"
            if "congestion" not in [inc["type"] for inc in current_incidents if inc["status"] == "active"]:
                incident = {
                    "id": congestion_id,
                    "type": "congestion",
                    "density": total_density,
                    "vehicles_per_lane": avg_vehicles_per_lane,
                    "start_time": datetime.fromtimestamp(current_time),
                    "status": "active"
                }
                current_incidents.append(incident)
                self.incidents.append(incident)
                self.active_incidents.add(congestion_id)
        else:
            # Resolve any active congestion incidents
            for incident in self.incidents:
                if incident["status"] == "active" and incident["type"] == "congestion":
                    incident["status"] = "resolved"
                    incident["end_time"] = datetime.fromtimestamp(current_time)
                    self.active_incidents.remove(incident["id"])

        return current_incidents

    def get_active_incidents(self) -> List[dict]:
        """Return all currently active incidents"""
        return [inc for inc in self.incidents if inc["status"] == "active"]

    def get_incident_history(self, limit: int = 100) -> List[dict]:
        """Return recent incident history"""
        return sorted(self.incidents, key=lambda x: x.get("start_time", datetime.now()), reverse=True)[:limit]

class DynamicTrafficController:
    """Adaptive traffic light control system"""

    def __init__(self):
        self.lane_states = {i: "red" for i in range(LANE_DIVISIONS)}
        self.current_green = None
        self.green_start_time = time.time()
        self.last_change = time.time()
        self.emergency_mode = False
        self.emergency_lane = None
        self.phase_history = []
        self.min_green_time = MIN_GREEN_TIME
        self.yellow_duration = YELLOW_DURATION
        self.red_duration = RED_DURATION

    def update_lights(self, densities: dict, incidents: list, emergency_present: bool = False) -> dict:
        """Update traffic light states based on conditions"""
        current_time = time.time()

        # Capture this state for history
        self.phase_history.append({
            "timestamp": current_time,
            "states": self.lane_states.copy(),
            "densities": densities.copy()
        })

        if len(self.phase_history) > 1000:
            self.phase_history = self.phase_history[-1000:]

        # Handle emergency vehicles first
        if emergency_present and not self.emergency_mode:
            self.emergency_mode = True
            self._enter_emergency_mode(densities)
            return self.lane_states
        elif self.emergency_mode and not emergency_present:
            self.emergency_mode = False
            self.emergency_lane = None

        # Check for incidents that need special handling
        has_major_incident = any(
            incident["type"] in ["accident", "roadblock"]
            for incident in incidents
        )

        if has_major_incident:
            return self._handle_major_incident(incidents)

        # Normal traffic flow management
        if self.emergency_mode:
            return self._update_emergency_mode()
        else:
            return self._update_normal_mode(densities, current_time)

    def _update_normal_mode(self, densities: dict, current_time: float) -> dict:
        """Update lights for normal traffic flow"""
        # Calculate green times based on density proportions
        if not densities:
            return self.lane_states

        total_density = sum(densities.values())
        if total_density == 0:
            # Default round-robin with minimum times if no traffic detected
            if self.current_green is None:
                self.current_green = 0
                self._set_green(self.current_green)
                self.green_start_time = current_time
            elif current_time - self.green_start_time > self.min_green_time:
                next_lane = (self.current_green + 1) % LANE_DIVISIONS
                self._transition_to_green(next_lane)
        else:
            # Dynamic timing based on traffic density
            green_times = {}
            for lane, density in densities.items():
                green_times[lane] = max(
                    self.min_green_time,
                    int((density / total_density) * (self.min_green_time * LANE_DIVISIONS))
                )

            # Initialize if no lane is currently green
            if self.current_green is None:
                densest_lane = max(densities, key=lambda k: densities[k])
                self.current_green = densest_lane
                self._set_green(self.current_green)
                self.green_start_time = current_time

            # Check if it's time to change
            current_green_time = green_times.get(self.current_green, self.min_green_time)
            if current_time - self.green_start_time > current_green_time:
                # Find next lane with highest density
                candidate_lanes = sorted(
                    densities.keys(),
                    key=lambda k: densities[k],
                    reverse=True
                )

                # Exclude current green lane
                candidate_lanes = [lane for lane in candidate_lanes if lane != self.current_green]

                if candidate_lanes:
                    next_lane = candidate_lanes[0]
                    self._transition_to_green(next_lane)

        return self.lane_states

    def _enter_emergency_mode(self, densities: dict) -> None:
        """Enter emergency vehicle priority mode"""
        # For now, just prioritize the lane with highest density
        # In a real system, this would use the specific lane with emergency vehicle
        if densities:
            self.emergency_lane = max(densities, key=lambda k: densities[k])
        else:
            self.emergency_lane = 0

        self._transition_to_green(self.emergency_lane)

    def _update_emergency_mode(self) -> dict:
        """Update lights during emergency mode"""
        # Keep emergency lane green
        if self.current_green != self.emergency_lane:
            self._transition_to_green(self.emergency_lane)
        return self.lane_states

    def _handle_major_incident(self, incidents: list) -> dict:
        """Handle traffic lights during major incidents"""
        # Simplistic approach: flash all yellow
        return {lane: "yellow" for lane in self.lane_states}

    def _set_green(self, lane: int) -> None:
        """Set a specific lane to green, all others to red"""
        for l in self.lane_states:
            self.lane_states[l] = "green" if l == lane else "red"
        self.current_green = lane

    def _transition_to_green(self, new_green: int) -> None:
        """Transition current green to yellow, then to red, then set new green"""
        # Set current green to yellow
        if self.current_green is not None:
            self.lane_states[self.current_green] = "yellow"
            time.sleep(self.yellow_duration)
            self.lane_states[self.current_green] = "red"
            time.sleep(self.red_duration)

        # Set new green
        self.lane_states[new_green] = "green"
        self.current_green = new_green
        self.green_start_time = time.time()
        self.last_change = time.time()

    def get_phase_history(self, limit: int = 100) -> List[dict]:
        """Get recent phase change history"""
        return self.phase_history[-limit:]

class TrafficMonitoringSystem:
    """Main system coordinating all components"""

    def __init__(self):
        self.detector = EnhancedVehicleDetector(MODEL_PATH)
        self.controller = DynamicTrafficController()
        self.predictor = TrafficPredictor()
        self.incident_detector = IncidentDetector()
        self.camera_streams = {}
        self.processing_queue = Queue()
        self.results_queue = Queue()
        self.running = False
        self.last_db_update = time.time()
        self.db_update_interval = 5  # seconds
        self.status = {
            "uptime": 0,
            "processed_frames": 0,
            "active_cameras": 0,
            "active_incidents": 0,
            "system_load": 0.0,
        }
        self.start_time = time.time()
        self.worker_threads = CONFIG.get("system", {}).get("worker_threads", 2)
        self.api_key = os.getenv("API_KEY") or str(uuid.uuid4())

        # Initialize Flask app
        self.app = Flask(__name__)
        self.setup_routes()

    def setup_routes(self):
        """Configure Flask API endpoints"""
        @self.app.route('/')
        def index():
            return render_template('index.html')

        @self.app.route('/api/status')
        def get_status():
            self._update_status()
            return jsonify(self.status)

        @self.app.route('/api/cameras')
        def get_cameras():
            return jsonify({
                "active": list(self.camera_streams.keys()),
                "available": CAMERA_URLS
            })

        @self.app.route('/api/traffic')
        def get_traffic():
            return jsonify({
                "lights": self.controller.lane_states,
                "history": self.controller.get_phase_history(),
                "prediction": self.predictor.update_and_predict({})  # Empty for now, real data in active mode
            })

        @self.app.route('/api/incidents')
        def get_incidents():
            return jsonify({
                "active": self.incident_detector.get_active_incidents(),
                "history": self.incident_detector.get_incident_history()
            })

        @self.app.route('/api/stream/<int:camera_id>')
        def video_feed(camera_id):
            if camera_id not in self.camera_streams:
                return "Camera not found", 404
            return Response(
                self._generate_frames(camera_id),
                mimetype='multipart/x-mixed-replace; boundary=frame'
            )

        @self.app.route('/api/camera/add', methods=['POST'])
        def add_camera():
            data = request.json
            if not data or 'url' not in data:
                return jsonify({"error": "No camera URL provided"}), 400

            if self._validate_api_key(request):
                camera_id = f"cam_{len(self.camera_streams) + 1}"
                success = self.add_camera_stream(camera_id, data['url'])
                if success:
                    return jsonify({"status": "success", "camera_id": camera_id})
                else:
                    return jsonify({"error": "Failed to connect to camera"}), 400
            else:
                return jsonify({"error": "Invalid API key"}), 401

        @self.app.route('/api/camera/remove/<camera_id>', methods=['POST'])
        def remove_camera(camera_id):
            if self._validate_api_key(request):
                if camera_id in self.camera_streams:
                    self.remove_camera_stream(camera_id)
                    return jsonify({"status": "success"})
                else:
                    return jsonify({"error": "Camera not found"}), 404
            else:
                return jsonify({"error": "Invalid API key"}), 401

        @self.app.route('/api/prediction', methods=['GET'])
        def api_prediction():
            if hasattr(self, 'latest_prediction'):
                return jsonify(self.latest_prediction)
            return jsonify({"error": "No prediction data available"}), 404

    def _validate_api_key(self, request):
        """Validate API key from request"""
        api_key = request.headers.get('X-API-Key')
        return api_key == self.api_key

    def _update_status(self):
        """Update system status information"""
        current_time = time.time()
        self.status["uptime"] = current_time - self.start_time
        self.status["active_cameras"] = len(self.camera_streams)
        self.status["active_incidents"] = len(self.incident_detector.get_active_incidents())

        try:
            import psutil
            self.status["system_load"] = psutil.cpu_percent()
            self.status["memory_usage"] = psutil.virtual_memory().percent
        except ImportError:
            self.status["system_load"] = 0.0
            self.status["memory_usage"] = 0.0

    def _generate_frames(self, camera_id):
        """Generate video frames for streaming"""
        if camera_id not in self.camera_streams:
            return

        while True:
            if camera_id not in self.camera_streams:
                break

            # Check if we have a new processed frame
            try:
                frame = self.camera_streams[camera_id]["processed_frame"]
                if frame is not None:
                    # Encode frame for HTTP streaming
                    ret, buffer = cv2.imencode('.jpg', frame)
                    if not ret:
                        continue
                    yield (b'--frame\r\n'
                           b'Content-Type: image/jpeg\r\n\r\n' + buffer.tobytes() + b'\r\n')
                    time.sleep(0.1)  # Limit frame rate
            except Exception as e:
                logger.error(f"Error generating frames: {e}")
                time.sleep(0.5)

    def add_camera_stream(self, camera_id, url):
        """Add new camera stream by URL"""
        try:
            # Test camera connection
            cap = cv2.VideoCapture(url)
            if not cap.isOpened():
                logger.error(f"Failed to open camera: {url}")
                return False

            ret, frame = cap.read()
            if not ret:
                logger.error(f"Failed to read from camera: {url}")
                cap.release()
                return False

            # Camera is working, add to streams
            self.camera_streams[camera_id] = {
                "url": url,
                "cap": cap,
                "processed_frame": None,
                "last_frame": None,
                "stats": {
                    "processed_frames": 0,
                    "fps": 0,
                    "start_time": time.time()
                }
            }

            logger.info(f"Added camera stream: {camera_id} - {url}")
            return True
        except Exception as e:
            logger.error(f"Error adding camera: {e}")
            return False

    def remove_camera_stream(self, camera_id):
        """Remove and cleanup camera stream"""
        if camera_id in self.camera_streams:
            try:
                # Release OpenCV capture
                self.camera_streams[camera_id]["cap"].release()
            except Exception as e:
                logger.error(f"Error releasing camera: {e}")

            # Remove from dictionary
            del self.camera_streams[camera_id]
            logger.info(f"Removed camera stream: {camera_id}")

    def start(self):
        """Start the monitoring system"""
        if self.running:
            logger.warning("System is already running")
            return

        self.running = True
        self.start_time = time.time()

        # Start worker threads for frame processing
        logger.info(f"Starting {self.worker_threads} worker threads")
        for i in range(self.worker_threads):
            thread = threading.Thread(target=self._process_frames_worker, daemon=True)
            thread.start()

        # Add camera streams from config
        for i, url in enumerate(CAMERA_URLS):
            camera_id = f"cam_{i+1}"
            self.add_camera_stream(camera_id, url)

        # Start frame capture threads
        for camera_id in self.camera_streams:
            thread = threading.Thread(target=self._capture_frames, args=(camera_id,), daemon=True)
            thread.start()

        # Start results handling thread
        thread = threading.Thread(target=self._handle_results, daemon=True)
        thread.start()

        # Register signal handlers
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)

        logger.info("Traffic monitoring system started")

        # Start Flask app
        if not os.environ.get("WERKZEUG_RUN_MAIN"):
            logger.info("Starting web interface on http://localhost:5000")
        self.app.run(host='0.0.0.0', debug=False)

    def stop(self):
        """Stop the monitoring system"""
        logger.info("Stopping traffic monitoring system...")
        self.running = False

        # Clean up camera streams
        for camera_id in list(self.camera_streams.keys()):
            self.remove_camera_stream(camera_id)

        # Wait for queues to empty
        while not self.processing_queue.empty():
            try:
                self.processing_queue.get(block=False)
            except Empty:
                break

        while not self.results_queue.empty():
            try:
                self.results_queue.get(block=False)
            except Empty:
                break

        # Save prediction model if we have enough data
        if len(self.predictor.history) > self.predictor.min_samples_for_prediction:
            self.predictor.save_model("traffic_predictor.h5")

        logger.info("Traffic monitoring system stopped")

    def _signal_handler(self, sig, frame):
        """Handle termination signals"""
        logger.info(f"Received signal {sig}, shutting down...")
        self.stop()
        sys.exit(0)

    def _capture_frames(self, camera_id):
        """Continuously capture frames from camera"""
        if camera_id not in self.camera_streams:
            return

        logger.info(f"Starting frame capture for {camera_id}")
        cap = self.camera_streams[camera_id]["cap"]
        frame_count = 0
        start_time = time.time()

        while self.running and camera_id in self.camera_streams:
            try:
                ret, frame = cap.read()
                if not ret:
                    logger.warning(f"Failed to read frame from {camera_id}, reconnecting...")
                    # Try to reconnect
                    url = self.camera_streams[camera_id]["url"]
                    cap.release()
                    cap = cv2.VideoCapture(url)
                    if not cap.isOpened():
                        logger.error(f"Failed to reconnect to {camera_id}")
                        time.sleep(5)  # Wait before trying again
                        continue
                    self.camera_streams[camera_id]["cap"] = cap
                    continue

                # Update camera statistics
                frame_count += 1
                elapsed = time.time() - start_time
                if elapsed >= 1.0:  # Update FPS every second
                    self.camera_streams[camera_id]["stats"]["fps"] = frame_count / elapsed
                    frame_count = 0
                    start_time = time.time()

                # Store original frame
                self.camera_streams[camera_id]["last_frame"] = frame

                # Add to processing queue
                self.processing_queue.put((camera_id, frame.copy(), time.time()))

                # Don't overwhelm the system
                time.sleep(0.1)

            except Exception as e:
                logger.error(f"Error capturing frame from {camera_id}: {e}")
                time.sleep(1)

    def _process_frames_worker(self):
        """Worker thread for processing frames"""
        logger.info("Frame processing worker started")

        while self.running:
            try:
                # Get frame from queue with timeout
                camera_id, frame, timestamp = self.processing_queue.get(timeout=1.0)

                # Process frame
                vehicle_counts, lane_densities, emergency_present, processed_frame, violations = \
                    self.detector.detect_and_track(frame)

                # Update statistics
                self.status["processed_frames"] += 1
                if camera_id in self.camera_streams:
                    self.camera_streams[camera_id]["stats"]["processed_frames"] += 1

                # Detect incidents
                frame_dimensions = (frame.shape[0], frame.shape[1])
                incidents = self.incident_detector.detect(
                    self.detector.tracker, lane_densities, frame_dimensions
                )

                # Update traffic light controller
                light_states = self.controller.update_lights(
                    lane_densities, incidents, emergency_present
                )

                # Make traffic predictions
                predictions = self.predictor.update_and_predict(lane_densities)

                # Store results
                self.results_queue.put({
                    "camera_id": camera_id,
                    "timestamp": timestamp,
                    "vehicle_counts": vehicle_counts,
                    "lane_densities": lane_densities,
                    "emergency_present": emergency_present,
                    "processed_frame": processed_frame,
                    "violations": violations,
                    "incidents": incidents,
                    "light_states": light_states,
                    "predictions": predictions
                })

                # Mark task as done
                self.processing_queue.task_done()

            except Empty:
                # Queue is empty, no problem
                continue
            except Exception as e:
                logger.error(f"Error processing frame: {e}", exc_info=True)
                time.sleep(0.5)

    def _handle_results(self):
        """Process and store detection results"""
        logger.info("Results handler started")

        while self.running:
            try:
                # Get results with timeout
                results = self.results_queue.get(timeout=1.0)

                # Update processed frame in camera stream
                camera_id = results["camera_id"]
                if camera_id in self.camera_streams:
                    self.camera_streams[camera_id]["processed_frame"] = results["processed_frame"]

                # Store to database if enabled
                if traffic_db and time.time() - self.last_db_update > self.db_update_interval:
                    self._update_database(results)
                    self.last_db_update = time.time()

                # Send alerts for incidents if needed
                self._check_and_send_alerts(results["incidents"])

                # Mark task as done
                self.results_queue.task_done()

            except Empty:
                # Queue is empty, no problem
                continue
            except Exception as e:
                logger.error(f"Error handling results: {e}", exc_info=True)
                time.sleep(0.5)

    def _update_database(self, results):
        """Store traffic data in database"""
        if not traffic_db:
            return

        try:
            # Store traffic data
            traffic_db.traffic_data.insert_one({
                "timestamp": datetime.now(),
                "camera_id": results["camera_id"],
                "vehicle_counts": results["vehicle_counts"],
                "lane_densities": results["lane_densities"],
                "light_states": results["light_states"],
                "predictions": results["predictions"]
            })

            # Store incidents
            for incident in results["incidents"]:
                traffic_db.incidents.insert_one({
                    "timestamp": datetime.now(),
                    "camera_id": results["camera_id"],
                    "incident": incident
                })

            # Store violations
            for violation in results["violations"]:
                traffic_db.violations.insert_one({
                    "timestamp": datetime.now(),
                    "camera_id": results["camera_id"],
                    "violation": violation
                })

        except Exception as e:
            logger.error(f"Database update failed: {e}")

    def _check_and_send_alerts(self, incidents):
        """Check for incidents requiring alerts"""
        if not twilio_client or not ALERT_PHONE_NUMBER:
            return

        # Check for new incidents that need immediate attention
        for incident in incidents:
            if incident["type"] in ["accident", "stopped_vehicle"] and "notified" not in incident:
                self._send_alert(incident)
                # Mark as notified to prevent duplicate alerts
                incident["notified"] = True

    def _send_alert(self, incident):
        """Send SMS alert via Twilio"""
        if not twilio_client or not ALERT_PHONE_NUMBER:
            logger.warning("Cannot send alert: Twilio not configured")
            return

        try:
            incident_type = incident["type"].replace("_", " ").title()
            message = f"ALERT: {incident_type} detected at {incident['start_time'].strftime('%H:%M:%S')}."

            if "position" in incident:
                message += f" Location: {incident['position']}"

            twilio_client.messages.create(
                body=message,
                from_=TWILIO_PHONE_NUMBER,
                to=ALERT_PHONE_NUMBER
            )

            logger.info(f"Alert sent for {incident['type']}")

        except Exception as e:
            logger.error(f"Failed to send alert: {e}")

def parse_arguments():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(description="Traffic Monitoring System")
    parser.add_argument("--config", type=str, default="config.yml",
                        help="Path to configuration file")
    parser.add_argument("--debug", action="store_true",
                        help="Enable debug logging")
    parser.add_argument("--no-web", action="store_true",
                        help="Disable web interface")
    parser.add_argument("--port", type=int, default=5000,
                        help="Port for web interface")
    return parser.parse_args()

if __name__ == "__main__":
    # Parse command line arguments
    args = parse_arguments()

    # Set logging level from arguments
    if args.debug:
        logging.getLogger().setLevel(logging.DEBUG)

    # Load configuration from specified file
    try:
        CONFIG = load_config(args.config)
    except FileNotFoundError:
        logger.warning(f"Config file '{args.config}' not found, using default configuration")
        CONFIG = load_config()  # Will use the default config from the function

    try:
        # Create and start system
        system = TrafficMonitoringSystem()

        # Apply command-line port setting to Flask app
        if hasattr(args, 'port'):
            port = args.port
        else:
            port = 5000

        # Start the system (modified to use the port)
        if args.no_web:
            # Run without web interface
            system.running = True
            # Start all the processing threads manually
            # [thread starting code from the start() method without Flask]
            # Wait for shutdown signal
            try:
                while system.running:
                    time.sleep(1)
            except KeyboardInterrupt:
                system.stop()
        else:
            # Start with web interface on specified port
            system.app.run(host='0.0.0.0', port=port, debug=False)

    except KeyboardInterrupt:
        logger.info("Keyboard interrupt received, shutting down...")
        if 'system' in locals():
            system.stop()
